<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            ServiceSeeder::class,
            TeamSeeder::class,
            GallerySeeder::class,
            NewsSeeder::class,
            TestimonialSeeder::class,
        ]);
    }
}