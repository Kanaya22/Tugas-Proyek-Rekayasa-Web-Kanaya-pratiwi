<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Service;

class ServiceSeeder extends Seeder
{
    public function run(): void
    {
        $data = [
            [
                'title' => 'Digital Marketing',
                'description' => 'Strategi marketing modern.',
                'icon' => 'bi bi-megaphone'
            ],
            [
                'title' => 'Content Creator',
                'description' => 'Konten kreatif viral.',
                'icon' => 'bi bi-camera-video'
            ]
        ];

        foreach ($data as $item) {
            Service::create($item);
        }
    }
}