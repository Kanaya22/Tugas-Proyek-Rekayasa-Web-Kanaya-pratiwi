<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Gallery;

class GallerySeeder extends Seeder
{
    public function run(): void
    {
        $galleries = [

            [
                'title' => 'Concert Event',
                'image' => 'images/gallery/gallery1.jpg'
            ],

            [
                'title' => 'Studio Session',
                'image' => 'images/gallery/gallery2.jpg'
            ],

        ];

        foreach($galleries as $gallery){

            Gallery::create($gallery);

        }
    }
}