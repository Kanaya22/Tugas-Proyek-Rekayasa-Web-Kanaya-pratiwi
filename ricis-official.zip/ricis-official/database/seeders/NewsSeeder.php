<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\News; // Pastikan memanggil model News yang benar

class NewsSeeder extends Seeder
{
    public function run(): void
    {
        News::create([
            'title' => 'penampilan terbaru ria ricis',
            'content' => 'penampilan ria ricis jadi sorotan usai melakukan operasi plastik',
            'image' => 'news1.jpg'
        ]);
        News::create([
            'title' => 'rumah baru ria ricis',
            'content' => 'rumah yang telah dibangun ria ricis sebentar lagi akan segera ditempati',
            'image' => 'news2.jpg'
        ]);
    }
}