<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Team;

class TeamSeeder extends Seeder
{
    public function run(): void
    {
        $teams = [

            [
                'name' => 'Vazo Achmad (Vazo)',
                'position' => 'Team Ricis',
                'photo' => 'images/team/team1.jpg'
            ],

            [
                'name' => 'Aryesh Jiannarta',
                'position' => 'Team Ricis',
                'photo' => 'images/team/team2.jpg'
            ],

            [
                'name' => 'Derry',
                'position' => 'Team Ricis',
                'photo' => 'images/team/team3.jpg'
            ],

            [
                'name' => 'Wildan Alamsyah',
                'position' => 'Team Ricis',
                'photo' => 'images/team/team4.jpg'
            ],


        ];

        foreach($teams as $team){

            Team::create($team);

        }
    }
}