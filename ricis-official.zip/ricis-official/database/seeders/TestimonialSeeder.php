<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Testimonial;

class TestimonialSeeder extends Seeder
{
    public function run(): void
    {
        for ($i = 1; $i <= 10; $i++) {

            Testimonial::create([
                'name' => 'Client '.$i,
                'message' => 'Pelayanan sangat memuaskan dan profesional.'
            ]);

        }
    }
}