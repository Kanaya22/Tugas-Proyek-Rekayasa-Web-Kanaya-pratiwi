

<?php $__env->startSection('content'); ?>

<section class="team-section">

    <div class="container">

        <div class="text-center mb-5">
            <h1 class="section-title">Meet Our Team</h1>
            <p class="section-subtitle">
                Creative people behind Ricis Official.
            </p>
        </div>

        <div class="row g-4">

            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-3 col-md-6">

                <div class="team-card">

                    <img src="<?php echo e(asset($team->photo)); ?>" class="img-fluid">

                    <div class="team-content">
                        <h4><?php echo e($team->name); ?></h4>
                        <p><?php echo e($team->position); ?></p>
                    </div>

                </div>

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ricis-official\resources\views/team.blade.php ENDPATH**/ ?>