

<?php $__env->startSection('content'); ?>

<section class="news-section">

    <div class="container">

        <div class="text-center mb-5">

            <h1 class="section-title">
                Latest News
            </h1>

            <p class="section-subtitle">
                Update terbaru dari Ricis Official.
            </p>

        </div>

        <?php if(session('login')): ?>

<form action="/news/store"
method="POST"
enctype="multipart/form-data">

<?php echo csrf_field(); ?>


<input 
type="text"
name="title"
placeholder="Judul News"
class="form-control">


<br>


<textarea 
name="content"
placeholder="Isi berita"
class="form-control"></textarea>


<br>


<input 
type="file"
name="image">


<br><br>


<button class="btn btn-danger">
Tambah News
</button>


</form>

<?php endif; ?>


        <div class="row g-4">


            <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            <div class="col-lg-4">


                <div class="news-card">


                    <?php if($item->image): ?>

                    <img 
                    src="<?php echo e(asset('storage/'.$item->image)); ?>" 
                    class="img-fluid"
                    alt="<?php echo e($item->title); ?>">

                    <?php endif; ?>



                    <div class="p-4">


                        <h4>
                            <?php echo e($item->title); ?>

                        </h4>



                        <p>

                            <?php echo e(Str::limit($item->content, 100)); ?>


                        </p>



                        <a href="#" class="service-btn">

                            Read More

                        </a>


                    </div>


                </div>


            </div>


            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>


    </div>

    <?php if(session('login')): ?>

<a href="/news/pdf" class="btn btn-primary">
Download PDF
</a>

<?php endif; ?>


</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ricis-official\resources\views/news.blade.php ENDPATH**/ ?>