

<?php $__env->startSection('content'); ?>

<section class="services-section">

    <div class="container">

        <div class="text-center mb-5">
            <h1 class="section-title">Our Services</h1>
            <p class="section-subtitle">
                Professional creative services for digital entertainment and branding.
            </p>
        </div>

        <div class="row g-4">

            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-lg-4 col-md-6">

                <div class="service-card">

                    <div class="service-icon">
                        <i class="<?php echo e($service->icon); ?>"></i>
                    </div>

                    <h3><?php echo e($service->title); ?></h3>

                    <p><?php echo e($service->description); ?></p>

                    <a href="/contact" class="service-btn">
                        Learn More
                    </a>

                </div>

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>

    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ricis-official\resources\views/services.blade.php ENDPATH**/ ?>