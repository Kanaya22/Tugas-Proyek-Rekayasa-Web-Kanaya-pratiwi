

<?php $__env->startSection('content'); ?>

<section class="hero">
    <div>
        <h1>RICIS OFFICIAL</h1>
        <p class="fs-4">Creative Digital & Entertainment Agency</p>
        <a href="/about" class="btn btn-danger btn-lg mt-3">Explore More</a>
    </div>
</section>

<section class="section">
    <div class="container">

        <div class="text-center mb-5">
            <h2 class="fw-bold">Our Services</h2>
        </div>

        <div class="row g-4">
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h4><?php echo e($service->title); ?></h4>
                    <p><?php echo e($service->description); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</section>

<section class="section bg-light">
    <div class="container">

        <div class="text-center mb-5">
            <h2 class="fw-bold">Our Team</h2>
        </div>

        <div class="row g-4">
            <?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $team): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3">
                <div class="card text-center p-3">
                    <img src="<?php echo e($team->photo); ?>" class="img-fluid rounded-circle mb-3">
                    <h5><?php echo e($team->name); ?></h5>
                    <p><?php echo e($team->position); ?></p>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</section>

<section class="section">
    <div class="container">

        <div class="text-center mb-5">
            <h2 class="fw-bold">Gallery</h2>
        </div>

        <div class="row g-4">
            <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4">
                <div class="card overflow-hidden">
                    <img src="<?php echo e($gallery->image); ?>" class="img-fluid">
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\ricis-official\resources\views/home.blade.php ENDPATH**/ ?>