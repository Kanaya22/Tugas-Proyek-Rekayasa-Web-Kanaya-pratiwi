<!DOCTYPE html>
<html>

<head>

<title>
Login Admin Ricis Official
</title>


<style>

body{
    margin:0;
    height:100vh;
    display:flex;
    justify-content:center;
    align-items:center;
    background:
    linear-gradient(135deg,#111,#e63946);
    font-family:Arial;
}


.login-box{

    width:350px;
    background:white;
    padding:40px;
    border-radius:20px;
    box-shadow:0 10px 30px #0005;

}


h1{
    text-align:center;
    color:#e63946;
}


input{

    width:100%;
    padding:12px;
    margin:10px 0;
    border-radius:10px;
    border:1px solid #ddd;

}


button{

    width:100%;
    padding:12px;
    border:none;
    border-radius:10px;
    background:#e63946;
    color:white;
    font-size:16px;

}


button:hover{
    background:#c1121f;
}


</style>


</head>


<body>


<div class="login-box">


<h1>
RICIS OFFICIAL
</h1>


<form action="/login" method="POST">

<?php echo csrf_field(); ?>


<input 
type="email"
name="email"
placeholder="Email">


<input
type="password"
name="password"
placeholder="Password">


<button>
Login
</button>


</form>


</div>


</body>

</html><?php /**PATH C:\laragon\www\ricis-official\resources\views/login.blade.php ENDPATH**/ ?>