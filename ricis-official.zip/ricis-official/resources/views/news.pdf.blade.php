<!DOCTYPE html>
<html>

<head>
<title>Laporan News</title>

<style>

table{
width:100%;
border-collapse:collapse;
}

td,th{
border:1px solid black;
padding:8px;
}

</style>

</head>


<body>


<h1>Ricis Official News</h1>


<table>

<tr>
<th>Judul</th>
<th>Isi</th>
</tr>


@foreach($data as $item)

<tr>

<td>
{{ $item->title }}
</td>

<td>
{{ $item->content }}
</td>

</tr>

@endforeach


</table>


</body>

</html>