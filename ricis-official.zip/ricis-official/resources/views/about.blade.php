@extends('layouts.app')

@section('content')

<section class="about-section">

    <div class="container">

        <div class="row align-items-center g-5">

            <!-- GAMBAR -->

            <div class="col-lg-6">

                <div class="about-image">

                    <img
    src="{{ asset('images/ricisofficial.jpg') }}"
    class="img-fluid">

                </div>

            </div>

            <!-- TEXT -->

            <div class="col-lg-6">

                <h1 class="about-title">
                    About Ricis Official
                </h1>

                <p class="about-text">

                    Ricis Official adalah creative entertainment company
                    yang bergerak di bidang digital media, content creator,
                    branding, social media management, dan entertainment production.

                </p>

                <p class="about-text">

                    Kami membantu brand dan talent berkembang melalui
                    strategi digital modern, visual cinematic,
                    serta creative marketing yang inovatif.

                </p>

                <div class="mt-4">

                    <a href="/services" class="btn-custom">
                        Explore Services
                    </a>

                </div>

            </div>

        </div>

    </div>

</section>

@endsection