<!DOCTYPE html>
<html>

<head>

    <title>
        Tambah News
    </title>


    <style>

        body{
            font-family: Arial;
            padding:40px;
        }

        input, textarea{
            width:100%;
            padding:10px;
            margin-bottom:15px;
        }

        button{
            padding:10px 20px;
            cursor:pointer;
        }

    </style>


</head>


<body>


<h1>
    Tambah Berita
</h1>



<form action="/admin/news/store" 
method="POST" 
enctype="multipart/form-data">


@csrf



<label>
    Judul Berita
</label>

<br>

<input 
type="text" 
name="title"
placeholder="Masukkan judul berita">



<br>


<label>
    Isi Berita
</label>

<br>


<textarea 
name="content"
rows="8"
placeholder="Masukkan isi berita"></textarea>




<br>


<label>
    Upload Gambar
</label>


<br>


<input 
type="file" 
name="image">



<br><br>



<button type="submit">

    Simpan

</button>



</form>



</body>

</html>