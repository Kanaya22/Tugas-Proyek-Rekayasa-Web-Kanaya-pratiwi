@extends('layouts.app')

@section('content')

<section class="news-section">

    <div class="container">

        <div class="text-center mb-5">

            <h1 class="section-title">
                Latest News
            </h1>

            <p class="section-subtitle">
                Update terbaru dari Ricis Official.
            </p>

        </div>

        @if(session('login'))

<form action="/news/store"
method="POST"
enctype="multipart/form-data">

@csrf


<input 
type="text"
name="title"
placeholder="Judul News"
class="form-control">


<br>


<textarea 
name="content"
placeholder="Isi berita"
class="form-control"></textarea>


<br>


<input 
type="file"
name="image">


<br><br>


<button class="btn btn-danger">
Tambah News
</button>


</form>

@endif


        <div class="row g-4">


            @foreach($news as $item)


            <div class="col-lg-4">


                <div class="news-card">


                    @if($item->image)

                    <img 
                    src="{{ asset('storage/'.$item->image) }}" 
                    class="img-fluid"
                    alt="{{ $item->title }}">

                    @endif



                    <div class="p-4">


                        <h4>
                            {{ $item->title }}
                        </h4>



                        <p>

                            {{ Str::limit($item->content, 100) }}

                        </p>



                        <a href="#" class="service-btn">

                            Read More

                        </a>


                    </div>


                </div>


            </div>


            @endforeach



        </div>


    </div>

    @if(session('login'))

<a href="/news/pdf" class="btn btn-primary">
Download PDF
</a>

@endif


</section>


@endsection