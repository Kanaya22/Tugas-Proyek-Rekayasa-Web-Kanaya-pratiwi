@extends('layouts.app')

@section('content')

<section class="services-section">

    <div class="container">

        <div class="text-center mb-5">
            <h1 class="section-title">Our Services</h1>
            <p class="section-subtitle">
                Professional creative services for digital entertainment and branding.
            </p>
        </div>

        <div class="row g-4">

            @foreach($services as $service)

            <div class="col-lg-4 col-md-6">

                <div class="service-card">

                    <div class="service-icon">
                        <i class="{{ $service->icon }}"></i>
                    </div>

                    <h3>{{ $service->title }}</h3>

                    <p>{{ $service->description }}</p>

                    <a href="/contact" class="service-btn">
                        Learn More
                    </a>

                </div>

            </div>

            @endforeach

        </div>

    </div>

</section>

@endsection