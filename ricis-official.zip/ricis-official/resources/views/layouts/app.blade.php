<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ricis Official</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <style>
        body{
    font-family: Poppins;
    background: #0f0f0f;
}

/* NAVBAR */

.custom-navbar{
    background: rgba(15,15,15,0.75);
    backdrop-filter: blur(14px);
    padding: 15px 0;
    transition: 0.4s ease;
    border-bottom: 1px solid rgba(255,255,255,0.08);
}

.logo-text{
    font-size: 30px;
    font-weight: bold;
    letter-spacing: 2px;

    background: linear-gradient(45deg,#ff4d6d,#c77dff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.navbar-nav .nav-link{
    color: white !important;
    font-weight: 500;
    margin: 0 10px;
    position: relative;
    transition: 0.3s;
}

.navbar-nav .nav-link:hover{
    color: #ff4d6d !important;
    transform: translateY(-2px);
}

/* GARIS HOVER */

.navbar-nav .nav-link::after{
    content: '';
    position: absolute;
    left: 0;
    bottom: -6px;
    width: 0%;
    height: 3px;
    border-radius: 10px;

    background: linear-gradient(90deg,#ff4d6d,#c77dff);

    transition: 0.4s;
}

.navbar-nav .nav-link:hover::after{
    width: 100%;
}

/* BUTTON */

.btn-custom{
    background: linear-gradient(45deg,#ff4d6d,#c77dff);
    color: white;
    padding: 10px 25px;
    border-radius: 50px;
    font-weight: 600;
    text-decoration: none;
    transition: 0.4s;
    box-shadow: 0 0 20px rgba(199,125,255,.3);
}

.btn-custom:hover{
    transform: translateY(-3px) scale(1.03);
    box-shadow: 0 10px 25px rgba(255,77,109,.5);
    color: white;
}

/* HERO */


    .hero{
    height: 100vh;

    background:
    linear-gradient(rgba(0,0,0,.75), rgba(0,0,0,.8)),
    url('https://i.ytimg.com/vi/RLSkmXgbDmY/mqdefault.jpg');

    background-size: cover;
    background-position: center;
    background-attachment: fixed;

    display: flex;
    justify-content: center;
    align-items: center;

    text-align: center;
    color: white;
}

.hero h1{
    font-size: 80px;
    font-weight: 800;

    background: linear-gradient(45deg,#ffffff,#ff4d6d,#c77dff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.hero p{
    font-size: 22px;
    color: #ddd;
}

.section{
    padding: 100px 0;
}

.card{
    background: #1a1a1a;
    border: 1px solid rgba(255,255,255,0.06);
    border-radius: 20px;
    overflow: hidden;
    transition: 0.4s;
    color: white;
}

.card:hover{
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(199,125,255,.2);
}

footer{
    background: #080808;
    color: white;
    padding: 40px;
}

/* ABOUT */

.about-section{
    padding: 120px 0;
    background: #111;
}

.about-image{
    overflow: hidden;
    border-radius: 25px;
}

.about-image img{
    border-radius: 25px;
    transition: 0.5s;
    box-shadow: 0 20px 40px rgba(0,0,0,.5);
}

.about-image img:hover{
    transform: scale(1.05);
}

.about-title{
    font-size: 55px;
    font-weight: 800;
    margin-bottom: 25px;

    background: linear-gradient(45deg,#ffffff,#ff4d6d,#c77dff);

    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.about-text{
    color: #ddd;
    font-size: 18px;
    line-height: 1.9;
}

.about-image img{
    width: 100%;
    height: 500px;
    object-fit: cover;
}

.section-title{
    font-size: 60px;
    font-weight: 800;

    background: linear-gradient(45deg,#ffffff,#ff4d6d,#c77dff);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
}

.section-subtitle{
    color: #bbb;
    font-size: 18px;
}

.services-section,
.team-section,
.gallery-section,
.news-section,
.contact-section{
    padding: 120px 0;
    background: #111;
}

.service-card,
.team-card,
.news-card,
.contact-card{
    background: #1a1a1a;
    border-radius: 25px;
    overflow: hidden;
    padding: 30px;
    transition: 0.4s;
    border: 1px solid rgba(255,255,255,0.06);
}

.service-card:hover,
.team-card:hover,
.gallery-card:hover,
.news-card:hover{
    transform: translateY(-10px);
    box-shadow: 0 20px 40px rgba(199,125,255,.2);
}

.service-card h3,
.news-card h4,
.team-card h4{
    color: white;
    margin-top: 20px;
}

.service-card p,
.news-card p,
.team-card p{
    color: #bbb;
}

.service-icon{
    width: 80px;
    height: 80px;

    background: linear-gradient(45deg,#ff4d6d,#c77dff);

    display: flex;
    justify-content: center;
    align-items: center;

    border-radius: 20px;

    font-size: 30px;
    color: white;
}

.service-btn{
    display: inline-block;
    margin-top: 10px;
    color: #ff4d6d;
    text-decoration: none;
    font-weight: 600;
}

.team-card img,
.gallery-card img,
.news-card img{
    width: 100%;
    height: 300px;
    object-fit: cover;
}

.team-content{
    padding-top: 20px;
    text-align: center;
}

.gallery-card{
    border-radius: 25px;
    overflow: hidden;
}

.gallery-card img{
    transition: 0.5s;
}

.gallery-card:hover img{
    transform: scale(1.08);
}

.custom-input{
    background: #222;
    border: none;
    color: white;
    padding: 15px;
    border-radius: 15px;
}

.custom-input:focus{
    background: #222;
    color: white;
    box-shadow: 0 0 15px rgba(199,125,255,.3);
}
    </style>
</head>
<body>

<nav class="navbar navbar-expand-lg fixed-top custom-navbar">
    <div class="container">

        <a class="navbar-brand fw-bold logo-text" href="/">
            RICIS OFFICIAL
        </a>

        <button class="navbar-toggler border-0 shadow-none"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#navbarNav">

            <span class="navbar-toggler-icon"></span>

        </button>

        <div class="collapse navbar-collapse" id="navbarNav">

            <ul class="navbar-nav mx-auto gap-2">

                <li class="nav-item">
                    <a class="nav-link active" href="/">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/about">About</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/services">Services</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/team">Team</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/gallery">Gallery</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/news">News</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="/contact">Contact</a>
                </li>

            </ul>

            <a href="/contact" class="btn btn-danger px-4 rounded-pill fw-semibold">
                Let's Talk
            </a>

        </div>
    </div>
</nav>

@yield('content')

<footer class="text-center">
    <h5>Ricis Official</h5>
    <p>Creative Digital Agency & Entertainment</p>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
