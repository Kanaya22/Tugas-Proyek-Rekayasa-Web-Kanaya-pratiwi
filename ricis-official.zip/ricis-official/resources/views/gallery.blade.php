@extends('layouts.app')

@section('content')

<section class="gallery-section">

    <div class="container">

        <div class="text-center mb-5">
            <h1 class="section-title">Our Gallery</h1>
            <p class="section-subtitle">
                Moments and creative activities from Ricis Official.
            </p>
        </div>

        <div class="row g-4">

            @foreach($galleries as $gallery)

            <div class="col-lg-4 col-md-6">

                <div class="gallery-card">
                    <img src="{{ asset($gallery->image) }}" class="img-fluid">
                </div>

            </div>

            @endforeach

        </div>

    </div>

</section>

@endsection