<h1>
Dashboard Admin Ricis Official
</h1>


<p>
Selamat datang {{ session('nama') }}
</p>


<a href="/admin/news/create">
Tambah News
</a>


<br><br>


<a href="/news">
Lihat Website
</a>


<br><br>


<a href="/logout">
Logout
</a>