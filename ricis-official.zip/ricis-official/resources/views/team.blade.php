@extends('layouts.app')

@section('content')

<section class="team-section">

    <div class="container">

        <div class="text-center mb-5">
            <h1 class="section-title">Meet Our Team</h1>
            <p class="section-subtitle">
                Creative people behind Ricis Official.
            </p>
        </div>

        <div class="row g-4">

            @foreach($teams as $team)

            <div class="col-lg-3 col-md-6">

                <div class="team-card">

                    <img src="{{ asset($team->photo) }}" class="img-fluid">

                    <div class="team-content">
                        <h4>{{ $team->name }}</h4>
                        <p>{{ $team->position }}</p>
                    </div>

                </div>

            </div>

            @endforeach

        </div>

    </div>

</section>

@endsection