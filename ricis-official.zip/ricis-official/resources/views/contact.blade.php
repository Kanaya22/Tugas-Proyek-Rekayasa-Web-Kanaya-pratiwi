@extends('layouts.app')

@section('content')

<section class="contact-section">

    <div class="container">

        <div class="text-center mb-5">
            <h1 class="section-title">Contact Us</h1>
            <p class="section-subtitle">
                Let's collaborate with Ricis Official.
            </p>
        </div>

        <div class="row justify-content-center">

            <div class="col-lg-8">

                <div class="contact-card">

                    <form>

                        <div class="mb-4">
                            <input type="text" class="form-control custom-input" placeholder="Your Name">
                        </div>

                        <div class="mb-4">
                            <input type="email" class="form-control custom-input" placeholder="Your Email">
                        </div>

                        <div class="mb-4">
                            <textarea rows="5" class="form-control custom-input" placeholder="Your Message"></textarea>
                        </div>

                        <button class="btn-custom border-0">
                            Send Message
                        </button>

                    </form>

                </div>

            </div>

        </div>

    </div>

</section>

@endsection