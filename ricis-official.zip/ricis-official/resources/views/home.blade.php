@extends('layouts.app')

@section('content')

<section class="hero">
    <div>
        <h1>RICIS OFFICIAL</h1>
        <p class="fs-4">Creative Digital & Entertainment Agency</p>
        <a href="/about" class="btn btn-danger btn-lg mt-3">Explore More</a>
    </div>
</section>

<section class="section">
    <div class="container">

        <div class="text-center mb-5">
            <h2 class="fw-bold">Our Services</h2>
        </div>

        <div class="row g-4">
            @foreach($services as $service)
            <div class="col-md-4">
                <div class="card p-4 h-100">
                    <h4>{{ $service->title }}</h4>
                    <p>{{ $service->description }}</p>
                </div>
            </div>
            @endforeach
        </div>

    </div>
</section>

<section class="section bg-light">
    <div class="container">

        <div class="text-center mb-5">
            <h2 class="fw-bold">Our Team</h2>
        </div>

        <div class="row g-4">
            @foreach($teams as $team)
            <div class="col-md-3">
                <div class="card text-center p-3">
                    <img src="{{ $team->photo }}" class="img-fluid rounded-circle mb-3">
                    <h5>{{ $team->name }}</h5>
                    <p>{{ $team->position }}</p>
                </div>
            </div>
            @endforeach
        </div>

    </div>
</section>

<section class="section">
    <div class="container">

        <div class="text-center mb-5">
            <h2 class="fw-bold">Gallery</h2>
        </div>

        <div class="row g-4">
            @foreach($galleries as $gallery)
            <div class="col-md-4">
                <div class="card overflow-hidden">
                    <img src="{{ $gallery->image }}" class="img-fluid">
                </div>
            </div>
            @endforeach
        </div>

    </div>
</section>

@endsection
