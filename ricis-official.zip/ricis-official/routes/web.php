<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\AuthController;


// ======================
// WEBSITE UTAMA
// ======================

Route::get('/home', [HomeController::class, 'index']);

Route::get('/about', [HomeController::class, 'about']);

Route::get('/services', [HomeController::class, 'services']);

Route::get('/team', [HomeController::class, 'team']);

Route::get('/gallery', [HomeController::class, 'gallery']);

Route::get('/news', [HomeController::class, 'news']);

Route::get('/contact', [HomeController::class, 'contact']);



// ======================
// LOGIN ADMIN
// ======================

Route::get('/', [AuthController::class,'login']);

Route::post('/login', [AuthController::class,'proses']);

Route::get('/logout', [AuthController::class,'logout']);



// ======================
// TAMBAH NEWS
// ======================

// NEWS
Route::get('/home', [HomeController::class,'index']);

Route::get('/news', [HomeController::class,'news']);

Route::post('/news/store',
[HomeController::class,'storeNews']);

Route::get('/news/delete/{id}',
[HomeController::class,'deleteNews']);



// ======================
// PDF
// ======================

Route::get('/news/pdf',
[HomeController::class,'pdf']);