<?php

namespace App\Http\Controllers;
use App\Models\Service;
use App\Models\Team;
use App\Models\Gallery;
use App\Models\News;
use App\Models\Testimonial;
use PDF;


class HomeController extends Controller
{
    // HOME
    public function index()
    {
        // SERVICES
        $services = Service::latest()->take(6)->get();

        // TEAM (4 DATA)
        $teams = Team::latest()->take(4)->get();

        // GALLERY (2 DATA)
        $galleries = Gallery::latest()->take(2)->get();

        // NEWS (2 DATA)
        $news = News::latest()->take(2)->get();

        // TESTIMONIAL
        $testimonials = Testimonial::all();

        return view('home', compact(
            'services',
            'teams',
            'galleries',
            'news',
            'testimonials'
        ));
    }

    // ABOUT
    public function about()
    {
        return view('about');
    }

    // SERVICES
    public function services()
    {
        $services = Service::all();

        return view('services', compact('services'));
    }

    // TEAM
    public function team()
    {
        $teams = Team::all();

        return view('team', compact('teams'));
    }

    // GALLERY
    public function gallery()
    {
        $galleries = Gallery::all();

        return view('gallery', compact('galleries'));
    }

    // NEWS
    public function news()
    {
        $news = News::all();

        return view('news', compact('news'));
    }

    // tambah news
public function createNews()
{
    return view('admin.news.create');
}


// simpan news
public function storeNews(Request $request)
{

$request->validate([
'title'=>'required',
'content'=>'required',
'image'=>'required|image'
]);


$image = $request->file('image')->store('news');


News::create([
'title'=>$request->title,
'content'=>$request->content,
'image'=>$image
]);


return redirect('/news');

}


// hapus news
public function deleteNews($id)
{
    News::find($id)->delete();

    return redirect('/news');
}

public function pdf()
{

$data = News::all();


$pdf = PDF::loadView('news.pdf', compact('data'));


return $pdf->download('laporan-news.pdf');

}

    // CONTACT
    public function contact()
    {
        return view('contact');
    }
}