<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Admin;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    
     public function login()
    {
        return view('login');
    }


    public function proses(Request $request)
    {

        $admin = Admin::where('email', $request->email)->first();


        if($admin && Hash::check($request->password, $admin->password))
{

session([
'login'=>true,
'nama'=>$admin->nama
]);

return redirect('/home');

}

        return back()->with('error','Email atau password salah');

    }



    public function logout()
    {
        session()->forget('login');

        return redirect('/login');
    }

}