<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class News extends Model
{
    use HasFactory;

    // Tambahkan field yang boleh diisi jika perlu
    protected $fillable = ['title', 'content', 'image']; 
}